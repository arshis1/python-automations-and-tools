# This repository contains the practice programs in Python 3
